'use client';
import {entriesRequest} from '@/lib/api';
import {useEffect,useRef,useState} from 'react';
import {Clock3,Plus,ArrowUpRight,Pencil,Trash2,Check,Loader2,CalendarDays} from 'lucide-react';
import {Button} from '@/components/ui/button';
import {Input} from '@/components/ui/input';
import {Table,TableHeader,TableHead,TableBody,TableRow,TableCell} from '@/components/ui/table';
import {AlertDialog,AlertDialogContent,AlertDialogHeader,AlertDialogTitle,AlertDialogDescription,AlertDialogFooter,AlertDialogCancel,AlertDialogAction} from '@/components/ui/alert-dialog';
import {monthlyTotals,type Entry} from '@/lib/timesheet';
const number=(n:number)=>new Intl.NumberFormat('en',{maximumFractionDigits:2}).format(n);
const formatDate=(d:string)=>new Date(d+'T12:00:00').toLocaleDateString('en-GB',{day:'numeric',month:'short',year:'numeric'});
const monthName=(d:string)=>new Date(d+'-01T12:00:00').toLocaleDateString('en-GB',{month:'long',year:'numeric'});
function today(){const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;}
export default function Home(){
 const [entries,setEntries]=useState<Entry[]>([]),[loading,setLoading]=useState(true),[busy,setBusy]=useState(false),[error,setError]=useState(''),[message,setMessage]=useState('');
 const [date,setDate]=useState(''),[hours,setHours]=useState('8'),[description,setDescription]=useState(''),[editing,setEditing]=useState<string|null>(null),[deleting,setDeleting]=useState<Entry|null>(null);
 const dateInput=useRef<HTMLInputElement>(null);
 async function load(){setLoading(true);setError('');try{const r=await entriesRequest('/api/entries',{cache:'no-store'});const data=await r.json();if(!r.ok)throw new Error(data.error);setEntries(data.entries);}catch(e){setError(e instanceof Error?e.message:'Unable to load your entries.');}finally{setLoading(false);}}
 useEffect(()=>{setDate(today());void load();},[]);
 const months=monthlyTotals(entries),total=entries.reduce((n,e)=>n+e.hours,0);
 function reset(){setEditing(null);setDate(today());setHours('8');setDescription('');}
 async function save(event:React.FormEvent){event.preventDefault();setBusy(true);setError('');setMessage('');try{const r=await entriesRequest('/api/entries',{method:editing?'PUT':'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:editing,date,hours:Number(hours),description})});const data=await r.json();if(!r.ok)throw new Error(data.error);setEntries(data.entries);setMessage(editing?'Entry updated.':'Hours saved.');reset();}catch(e){setError(e instanceof Error?e.message:'Unable to save.');}finally{setBusy(false);}}
 async function remove(){if(!deleting)return;setBusy(true);setError('');try{const r=await entriesRequest('/api/entries',{method:'DELETE',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:deleting.id})});const data=await r.json();if(!r.ok)throw new Error(data.error);setEntries(data.entries);if(editing===deleting.id)reset();setDeleting(null);setMessage('Entry deleted.');}catch(e){setError(e instanceof Error?e.message:'Unable to delete.');}finally{setBusy(false);}}
 function edit(e:Entry){setEditing(e.id);setDate(e.date);setHours(String(e.hours));setDescription(e.description);setMessage('');dateInput.current?.focus();document.getElementById('entry-form')?.scrollIntoView({behavior:'smooth',block:'center'});}
 return <div className="app-shell">
  <header className="topbar"><a className="brand" href="./" aria-label="ExoTech Hours home"><span className="brand-icon"><Clock3 size={22}/></span><span>ExoTech<span className="brand-light"> / Hours</span></span></a><span className="workspace-badge">PERSONAL WORKSPACE</span></header>
  <main>
   <div className="page-heading"><div><h1>Fiona’s Part-Time Hours</h1></div><div className="small-note"><span className="status-dot"/>Saved as you log</div></div>
   <div className="workspace-grid"><section className="log-area">
    <section className="entry-card" id="entry-form"><div className="section-title"><h2>{editing?'Edit entry':'Log your time'}</h2><span className="pill">Full day = 8 hours</span></div>
     <form onSubmit={save}><div className="form-row"><label htmlFor="date">Date<Input ref={dateInput} id="date" type="date" min="1900-01-01" max="2100-12-31" value={date} onChange={e=>setDate(e.target.value)} required disabled={busy||loading}/></label><label htmlFor="hours">Hours<Input id="hours" type="number" min="0.01" max="24" step="0.01" inputMode="decimal" value={hours} onChange={e=>setHours(e.target.value)} required disabled={busy||loading}/></label></div>
     <label htmlFor="description">Description <span className="optional">optional</span><Input id="description" placeholder="What did you work on?" value={description} maxLength={1000} onChange={e=>setDescription(e.target.value)} disabled={busy||loading}/></label>
     <div className="form-footer"><div className="saved-message" role="status">{message&&<><Check size={16}/>{message}</>}</div><div className="form-actions">{editing&&<Button type="button" variant="ghost" onClick={reset} disabled={busy}>Cancel</Button>}<Button className="save-button" type="submit" disabled={busy||loading}>{busy?<Loader2 className="animate-spin"/>:<Plus size={18}/>} {editing?'Save changes':'Add entry'}</Button></div></div>
     </form>
    </section>
    {error&&<div role="alert" className="error-box">{error} <Button variant="link" onClick={()=>void load()} disabled={busy||loading}>Reload entries</Button></div>}
    <section className="entries-section"><div className="section-title"><h2>Work log</h2><span className="entry-count">{entries.length} {entries.length===1?'entry':'entries'}</span></div>
     {loading?<div className="empty-state"><Loader2 className="animate-spin"/> Loading your hours…</div>:!entries.length?<div className="empty-state"><CalendarDays size={28}/><h3>Your next workday starts here.</h3><p>Add your first entry above. Its month will appear automatically.</p></div>:<Table><TableHeader><TableRow><TableHead>Date</TableHead><TableHead>Description</TableHead><TableHead className="numeric">Hours</TableHead><TableHead><span className="sr-only">Actions</span></TableHead></TableRow></TableHeader><TableBody>{entries.map(e=><TableRow key={e.id}><TableCell className="date-cell"><span>{formatDate(e.date)}</span><small>{new Date(e.date+'T12:00:00').toLocaleDateString('en',{weekday:'long'})}</small></TableCell><TableCell className="description-cell">{e.description||<span className="muted-dash">—</span>}</TableCell><TableCell className="numeric hours-cell">{number(e.hours)}<span> h</span></TableCell><TableCell><div className="row-actions"><Button variant="ghost" size="icon" aria-label={`Edit entry for ${formatDate(e.date)}`} onClick={()=>edit(e)} disabled={busy}><Pencil size={16}/></Button><Button variant="ghost" size="icon" aria-label={`Delete entry for ${formatDate(e.date)}`} onClick={()=>setDeleting(e)} disabled={busy}><Trash2 size={16}/></Button></div></TableCell></TableRow>)}</TableBody></Table>}
    </section>
   </section>
   <aside className="totals-panel"><div className="total-card"><div className="total-label">TOTAL LOGGED <ArrowUpRight size={19}/></div><div className="total-number">{loading?'—':number(total)}<span>hrs</span></div><div className="total-caption">{months.length} {months.length===1?'month':'months'} · {entries.length} {entries.length===1?'entry':'entries'}</div><div className="total-rule"/><div className="card-foot"><Clock3 size={16}/> Every hour, in one place.</div></div>
    <section className="months-section"><div className="section-title"><h2>By month</h2><span className="auto-label">AUTO</span></div>{!loading&&months.length===0?<p className="month-empty">Months appear when you log hours.</p>:months.map(m=><div className="month-row" key={m.month}><div><h3>{monthName(m.month)}</h3><p>{m.count} {m.count===1?'entry':'entries'}</p></div><strong>{number(m.hours)}<span> hrs</span></strong></div>)}<p className="month-hint">Only months you’ve worked in appear here.</p></section>
   </aside></div>
   <footer>ExoTech Hours <span>Keep it simple. Keep it logged.</span></footer>
  </main>
  <AlertDialog open={Boolean(deleting)} onOpenChange={open=>{if(!open&&!busy)setDeleting(null);}}><AlertDialogContent><AlertDialogHeader><AlertDialogTitle>Delete this entry?</AlertDialogTitle><AlertDialogDescription>{deleting&&`${number(deleting.hours)} hours on ${formatDate(deleting.date)} will be removed from your log and monthly total.`}</AlertDialogDescription></AlertDialogHeader><AlertDialogFooter><AlertDialogCancel disabled={busy}>Keep entry</AlertDialogCancel><AlertDialogAction variant="destructive" disabled={busy} onClick={e=>{e.preventDefault();void remove();}}>{busy?'Deleting…':'Delete entry'}</AlertDialogAction></AlertDialogFooter></AlertDialogContent></AlertDialog>
 </div>;
}
