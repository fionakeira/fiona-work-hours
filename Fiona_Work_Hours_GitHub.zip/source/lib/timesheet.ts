export type Entry={id:string;date:string;hours:number;description:string};
export function monthlyTotals(entries:Entry[]){
 const totals=new Map<string,{hours:number;count:number}>();
 for(const e of entries){const key=e.date.slice(0,7);const m=totals.get(key)||{hours:0,count:0};m.hours+=e.hours;m.count++;totals.set(key,m);}
 return [...totals].sort(([a],[b])=>b.localeCompare(a)).map(([month,v])=>({month,hours:Math.round(v.hours*100)/100,count:v.count}));
}
export function validateEntry(data:unknown):Omit<Entry,'id'>|null{
 if(!data||typeof data!=='object')return null;
 const {date,hours,description}=data as Record<string,unknown>;
 if(typeof date!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(date)||date<'1900-01-01'||date>'2100-12-31')return null;
 const d=new Date(date+'T12:00:00Z');
 if(!Number.isFinite(d.getTime())||d.toISOString().slice(0,10)!==date)return null;
 if(typeof hours!=='number'||!Number.isFinite(hours)||hours<0.01||hours>24)return null;
 if(typeof description!=='string'||description.length>1000)return null;
 return {date,hours:Math.round(hours*100)/100,description:description.trim()};
}
