import {validateEntry,type Entry} from './timesheet';
type Config={supabaseUrl:string;supabasePublishableKey:string};
let config:Config|null=null;
async function getConfig(){
 if(config)return config;
 const r=await fetch(new URL('./config.json',document.baseURI),{cache:'no-store'});
 if(!r.ok)throw new Error('Cannot load the site configuration.');
 const c=await r.json() as Config;
 if(!c.supabaseUrl||!c.supabasePublishableKey)throw new Error('Database setup is not finished. Add your Supabase project URL and publishable key to config.json.');
 if(!/^https:\/\/[a-z0-9-]+\.supabase\.co\/?$/.test(c.supabaseUrl)||!c.supabasePublishableKey.startsWith('sb_publishable_'))throw new Error('Use your Supabase project URL and publishable key (sb_publishable_).');
 config={supabaseUrl:c.supabaseUrl.replace(/\/$/,''),supabasePublishableKey:c.supabasePublishableKey};return config;
}
export async function entriesRequest(_path:string,options:RequestInit={}){
 try{
 const c=await getConfig();const url=c.supabaseUrl+'/rest/v1/fiona_timesheet_entries';
 const headers={apikey:c.supabasePublishableKey,'Content-Type':'application/json'};
 const method=options.method||'GET';
 if(method!=='GET'){
 const body=JSON.parse(String(options.body||'{}'));
 if(method!=='DELETE'&&!validateEntry(body))throw new Error('Please enter a valid date and between 0.01 and 24 hours.');
 if((method==='DELETE'||method==='PUT')&&typeof body.id!=='string')throw new Error('Entry not found.');
 const target=method==='POST'?url:url+'?id=eq.'+encodeURIComponent(body.id);
 const payload=method==='DELETE'?undefined:JSON.stringify({...validateEntry(body),...(method==='POST'?{id:crypto.randomUUID()}: {})});
 const r=await fetch(target,{method:method==='PUT'?'PATCH':method,headers,body:payload});
 if(!r.ok)throw new Error('Could not save your change. Check your connection and the database setup.');
 }
 const entries:Entry[]=[];
 for(let offset=0;;offset+=1000){
 const r=await fetch(url+'?select=id,date,hours,description&order=date.desc,id.desc&offset='+offset+'&limit=1000',{headers,cache:'no-store'});
 if(!r.ok)throw new Error('Could not load your hours. Check your connection and the database setup.');
 const page=await r.json() as Entry[];entries.push(...page);if(page.length<1000)break;
 }
 return Response.json({entries});
 }catch(e){return Response.json({error:e instanceof Error?e.message:'Could not connect to your saved hours.'},{status:500});}
}
